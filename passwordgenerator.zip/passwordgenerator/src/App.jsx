import { useState, useCallback, useEffect } from 'react'
import './App.css'

function App() {

  // set the password length
  const [length, setLength] = useState(8)

  // set the numbers allowed
  const [numberAllowed, setNumberAllowed] = useState(false)

  // set the symbols allowed
  const [symbolAllowed, setSymbolAllowed] = useState(false)

  // set the generated password
  const [password, setPassword] = useState('')

  const generatePassword = useCallback(() => {

    let pass = ""
    let str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    
    if (numberAllowed) {
      str += "0123456789"
    }
    if (symbolAllowed) {
      str += "!@#$%^&*()_+"
    }

    for (let i = 0; i < length; i++) {
      const char = Math.floor(Math.random() * str.length)
      pass += str.charAt(char)
    }

    setPassword(pass)

  }, [length, numberAllowed, symbolAllowed])


  useEffect(() => {
    generatePassword()
    
  }, [generatePassword])


  return (
    <>
      <div>
        <h1>Password Generator</h1>

        <div className='input'>
          <input
            type='text'
            value={password}
            className='outline-none w-full py-1 px-3'
            placeholder='Password'
            readOnly
          />

          <button className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-4 rounded'>
            Copy
          </button>
        </div>

        <div className='flex text-sm gap-x-2'>
          <input
            type="range"
            min={8}
            max={100}
            value={length}
            className='cursor-pointer'
            onChange={(e) => setLength(Number(e.target.value))}
          />

          <label>Length: {length}</label>
        </div>

        <div className='flex text-sm gap-x-2'>
          <input
            type="checkbox"
            checked={numberAllowed}
            onChange={() => setNumberAllowed(prev => !prev)}
          />

          <label>Include Numbers</label>
        </div>

        <div className='flex text-sm gap-x-2'>
          <input
            type="checkbox"
            checked={symbolAllowed}
            onChange={() => setSymbolAllowed(prev => !prev)}
          />

          <label>Include Symbols</label>
        </div>

      </div>
    </>
  )
}

export default App