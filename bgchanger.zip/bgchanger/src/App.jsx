
import './App.css'
import { useState } from 'react'
// import tailwindcss from 'tailwindcss'

function App() {
  const [color, setColor] = useState('white')

  function changeColor(color){
    setColor(color)
  }


  return (
    <div className="w-full  h-screen duration-200" style={{backgroundColor: color}}>
      <h1 className='text-4xl font-bold text-center pt-40 text-white '>Background Color Changer in React JS</h1>
      <div className='fixed flex flex-wrap justify-center bottom-22 inset-x-0 px-2' >
        <div className='fixed justify-center gap-3 shadow-amber-900 px-3 py-2 rounded-3xl bg-white/80'>

                                                                                                    {/* OR Use: () => setColor('black')  */}
          <button className='outline-none px-4 py-1 m-1 rounded-full shadow-lg text-white' style={{ backgroundColor: 'black' }} onClick={() => changeColor('black')}>BLACK</button>
          <button className='outline-none px-4 py-1 m-1 rounded-full shadow-lg text-white' style={{ backgroundColor: 'green' }} onClick={() => changeColor('green')}>GREEN</button>
          <button className='outline-none px-4 py-1 m-1 rounded-full shadow-lg text-white' style={{ backgroundColor: 'red' }} onClick={() => changeColor('red')}>RED</button>
        </div>
      </div>

    </div>
  )
}

export default App
