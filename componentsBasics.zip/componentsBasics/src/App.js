// import {ProductCard} from './components/Products'; 

import './App.css';
import ProductCard from './components/props';
// import ProductCard2 from './components/SimpleComp';
// import ProductCard3 from './components/UsingJSXVar';
// import ProductCard4 from './components/ChildrenProp';
import { ProductList } from './components/ProductList';
import ProductCard5 from './components/useState';

import PropManip from './components/PropManip';

function App() {
  const product = {
    name: "iPhone 14 Pro Max",
    price: 1099,
    description: "The iPhone 14 Pro Max features a stunning display, powerful performance, and an advanced camera system that captures every moment in incredible detail."
};
  // let items = ["Cras justo odio", "Dapibus ac facilisis in", "Morbi leo risus", "Porta ac consectetur ac", "Vestibulum at eros"];
  return (
    <div className="container mt-5">
        {/* product={product}
            👉 This is passing props (data)
            Left side product → prop name
            Right side product → variable from your JS */}

      <ProductList>
        <ProductCard background="light" product={product} />
        {/* <ProductCard background="light" product={product} /> */}
        <PropManip product={product} background="lightsteelblue"/>
        <PropManip product={product} background="peru"/>
        <PropManip product={product} background="darkolivegreen"/>




        <ProductCard5 naam="John"/>







        {/* <ProductCard2 /> Using Simple Component
        <ProductCard3 />Using JSX Variable
        <ProductCard4><h2>iPhone 14</h2><p>Using Children Prop</p></ProductCard4> */}
      </ProductList>
        
    </div>
  );
}

export default App;
