function ProductCard4({ children }) {
    return (
     <> 
      <br></br>
      <div className="card">
        <div className="card-body">
        {children}
        </div>
      </div>
    </>  
    );
  }

export default ProductCard4;