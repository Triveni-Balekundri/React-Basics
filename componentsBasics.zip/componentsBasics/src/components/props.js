function ProductCard(props){
   
    return (
        
        <article
            style={{
            width: "100%",
            border: "1px solid black",
            borderRadius: "8px",
            padding: "16px",
            textAlign: "center",
            }}
            >
            <h2>{props.product.name}</h2>
            <p>Specification:</p>
            <p>{props.product.description}</p>
            <button>Buy (From ${props.product.price})</button>
        </article>
    );
}





export default ProductCard;