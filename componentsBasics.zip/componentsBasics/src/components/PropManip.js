import React from 'react'

function PropManip({product, background="slategray"}) {
    // const propw = product.prop;
  return (
    <article
            style={{
            background,
            width: "100%",
            border: "1px solid black",
            borderRadius: "8px",
            padding: "16px",
            textAlign: "center",
            }}
            >
            <h2>{product.name}</h2>
            <p>Specification:</p>
            <p>{product.description}</p>
            <button>Buy (From ${product.price})</button>
        </article>
  )
}

export default PropManip