export function ProductList(props) {
    return <div style={{display: 'flex', gap: 16}}>{props.children}</div>;
}