function ProductCard3(){
    const product = {
        name: "iPhone 18 Pro Max",
        price: 3099,
        description: "The iPhone 18 Pro Max features a stunning display, powerful performance, and an advanced camera system that captures every moment in incredible detail."
    };
    return (
        <>
        <br/>
        <div className="card">
          <div className="card-body">
                <h5 className="card-title">{product.name}</h5>
                <p className="card-text">{product.description}</p>
                <p className="card-text"><strong>${product.price.toFixed(2)}</strong></p>
            </div>
        </div>
        </>
    );

}

export default ProductCard3;