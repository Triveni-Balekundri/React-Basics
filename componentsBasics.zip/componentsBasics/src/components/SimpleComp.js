function ProductCard2(){
    return (
        <>
        <br/>
        <div className="card">
          <div className="card-body">
                <h5 className="card-title">iPhone 17 Pro Max</h5>
                <p className="card-text">The iPhone 17 Pro Max features a stunning display, powerful performance, and an advanced camera system that captures every moment in incredible detail.</p>
                <p className="card-text"><strong>$2,099.00</strong></p>
            </div>
        </div>
        </>
    );

}

export default ProductCard2;