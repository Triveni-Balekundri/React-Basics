
import { useState } from 'react'


function ProductCard5({naam}) {
    var [count, setCount] = useState(0);
    var [a,b] = useState(false);

  return (
    <div>
        <div>{count+1}{naam}</div>
        <button onClick={()=>setCount(count+1)}>Click</button>
        <br></br>
        {/* conditional rendering */}
        
        <h2>{a === false ? "Hello" : "World"}</h2>
        <button onClick={()=>b(!a)}>Check</button>
    </div>
  )
}

export default ProductCard5;